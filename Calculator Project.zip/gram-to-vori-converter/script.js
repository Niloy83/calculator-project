document.addEventListener('DOMContentLoaded', function() {
  const modeSwitch = document.getElementById('mode-switch');
  const gramToVoriSection = document.getElementById('gram-to-vori-section');
  const voriToGramSection = document.getElementById('vori-to-gram-section');

  const gramsInput = document.getElementById('grams');
  const pointsInput = document.getElementById('points');
  const resultGramToVori = document.getElementById('result-gram-to-vori');

  const voriInput = document.getElementById('vori');
  const anaInput = document.getElementById('ana');
  const ratiInput = document.getElementById('rati');
  const pointInput = document.getElementById('point');
  const resultVoriToGram = document.getElementById('result-vori-to-gram');

  modeSwitch.addEventListener('change', function() {
    if (modeSwitch.checked) {
      gramToVoriSection.style.display = 'none';
      voriToGramSection.style.display = 'block';
    } else {
      gramToVoriSection.style.display = 'block';
      voriToGramSection.style.display = 'none';
    }
  });

  gramsInput.addEventListener('input', convertGramToVori);
  pointsInput.addEventListener('input', convertGramToVori);

  voriInput.addEventListener('input', convertVoriToGram);
  anaInput.addEventListener('input', convertVoriToGram);
  ratiInput.addEventListener('input', convertVoriToGram);
  pointInput.addEventListener('input', convertVoriToGram);

  function convertGramToVori() {
    const grams = parseFloat(gramsInput.value) || 0;
    const points = parseFloat(pointsInput.value) || 0;
    const totalGrams = grams + (points * 0.012);

    const vori = Math.floor(totalGrams / 11.664);
    const remainingGrams = totalGrams % 11.664;
    const ana = Math.floor(remainingGrams / 0.729);
    const remainingAnaGrams = remainingGrams % 0.729;
    const rati = Math.floor(remainingAnaGrams / 0.12);
    const remainingRatiGrams = remainingAnaGrams % 0.12;
    const point = Math.round(remainingRatiGrams / 0.012);

    resultGramToVori.innerHTML = `
            <span class="bold">${convertToBanglaNumbers(vori)} ভরি</span>, 
            <span class="bold">${convertToBanglaNumbers(ana)} আনা</span>, 
            <span class="bold">${convertToBanglaNumbers(rati)} রতি</span>, 
            <span class="bold">${convertToBanglaNumbers(point)} পয়েন্ট</span>
        `;
  }

  function convertVoriToGram() {
    const vori = parseFloat(voriInput.value) || 0;
    const ana = parseFloat(anaInput.value) || 0;
    const rati = parseFloat(ratiInput.value) || 0;
    const point = parseFloat(pointInput.value) || 0;

    if (ana < 0 || ana > 15) {
      anaInput.style.borderColor = 'red';
      resultVoriToGram.innerHTML = 'আনা ০ থেকে ১৫ এর মধ্যে হতে হবে';
      return;
    } else {
      anaInput.style.borderColor = '#ced4da';
    }

    if (rati < 0 || rati > 5) {
      ratiInput.style.borderColor = 'red';
      resultVoriToGram.innerHTML = 'রতি ০ থেকে ৫ এর মধ্যে হতে হবে';
      return;
    } else {
      ratiInput.style.borderColor = '#ced4da';
    }

    if (point < 0 || point > 9) {
      pointInput.style.borderColor = 'red';
      resultVoriToGram.innerHTML = 'পয়েন্ট ০ থেকে ৯ এর মধ্যে হতে হবে';
      return;
    } else {
      pointInput.style.borderColor = '#ced4da';
    }

    const totalGrams = (vori * 11.664) + (ana * 0.729) + (rati * 0.12) + (point * 0.012);

    resultVoriToGram.innerHTML = `
            <span class="bold">${convertToBanglaNumbers(totalGrams.toFixed(2))} গ্রাম</span>
        `;
  }

  function convertToBanglaNumbers(number) {
    const banglaNumbers = {
      '0': '০',
      '1': '১',
      '2': '২',
      '3': '৩',
      '4': '৪',
      '5': '৫',
      '6': '৬',
      '7': '৭',
      '8': '৮',
      '9': '৯'
    };
    return number.toString().replace(/[0-9]/g, function(match) {
      return banglaNumbers[match];
    });
  }
});