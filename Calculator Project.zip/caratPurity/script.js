document.addEventListener('DOMContentLoaded', function() {
  const newBhoriSelect = document.getElementById("new-bhori");
  const newAnaSelect = document.getElementById("new-ana");
  const newRatiSelect = document.getElementById("new-rati");
  const newPointSelect = document.getElementById("new-point");

  initializeWeightOptions(newBhoriSelect, 50, 'ভরি');
  initializeWeightOptions(newAnaSelect, 15, 'আনা');
  initializeWeightOptions(newRatiSelect, 5, 'রতি');
  initializeWeightOptions(newPointSelect, 9, 'পয়েন্ট');

  function initializeWeightOptions(selectElement, max, label) {
    for (let i = 0; i <= max; i++) {
      const option = document.createElement("option");
      option.value = i;
      option.text = `${convertToBanglaNumbers(i)} ${label}`;
      selectElement.appendChild(option);
    }
  }

  const caratSelect = document.getElementById('carat');
  const resultGramsDiv = document.getElementById('result-grams');
  const resultTraditionalDiv = document.getElementById('result-traditional');
  const outputSection = document.getElementById('output');

  const inputs = [newBhoriSelect, newAnaSelect, newRatiSelect, newPointSelect, caratSelect];
  inputs.forEach(input => input.addEventListener('change', updateResults));

  const caratPurityMap = {
    16: { impurity: { ana: 5, rati: 2 }, pureGold: { ana: 10, rati: 4 } },
    17: { impurity: { ana: 4, rati: 4 }, pureGold: { ana: 11, rati: 2 } },
    18: { impurity: { ana: 4, rati: 0 }, pureGold: { ana: 12, rati: 0 } },
    19: { impurity: { ana: 3, rati: 2 }, pureGold: { ana: 12, rati: 4 } },
    20: { impurity: { ana: 2, rati: 4 }, pureGold: { ana: 13, rati: 2 } },
    21: { impurity: { ana: 2, rati: 0 }, pureGold: { ana: 14, rati: 0 } },
    22: { impurity: { ana: 1, rati: 2 }, pureGold: { ana: 14, rati: 4 } },
  };

  function updateResults() {
    const vori = parseInt(newBhoriSelect.value) || 0;
    const ana = parseInt(newAnaSelect.value) || 0;
    const rati = parseInt(newRatiSelect.value) || 0;
    const point = parseInt(newPointSelect.value) || 0;
    const carat = parseInt(caratSelect.value);

    const voriInGrams = 11.66;
    const anaInGrams = 0.729;
    const ratiInGrams = 0.12;
    const pointInGrams = 0.012;

    const totalWeightInGrams = (vori * voriInGrams) + (ana * anaInGrams) + (rati * ratiInGrams) + (point * pointInGrams);

    const impurity = caratPurityMap[carat].impurity;
    const pureGold = caratPurityMap[carat].pureGold;

    const impurityWeightInGrams = (impurity.ana * anaInGrams) + (impurity.rati * ratiInGrams);
    const pureGoldWeightInGrams = totalWeightInGrams - impurityWeightInGrams;

    outputSection.style.display = 'block';
    resultGramsDiv.innerHTML = `
            <strong>গ্রাম:</strong><br>
            মোট সোনার পরিমাণ: ${convertToBanglaNumbers(totalWeightInGrams.toFixed(2))} গ্রাম<br>
            খাদ এর পরিমাণ: ${convertToBanglaNumbers(impurityWeightInGrams.toFixed(2))} গ্রাম<br>
            <span class="bold">খাঁটি সোনার পরিমাণ: ${convertToBanglaNumbers(pureGoldWeightInGrams.toFixed(2))} গ্রাম</span>
        `;

    resultTraditionalDiv.innerHTML = `
            <strong>ভরি, আনা, রতি, পয়েন্ট:</strong><br>
            মোট সোনার পরিমাণ: ${convertToBanglaNumbers(vori)} ভরি, ${convertToBanglaNumbers(ana)} আনা, ${convertToBanglaNumbers(rati)} রতি, ${convertToBanglaNumbers(point)} পয়েন্ট<br>
            খাদ এর পরিমাণ: ${convertToBanglaNumbers(impurity.ana)} আনা, ${convertToBanglaNumbers(impurity.rati)} রতি<br>
            <span class="bold">খাঁটি সোনার পরিমাণ: ${convertToBanglaNumbers(pureGold.ana)} আনা, ${convertToBanglaNumbers(pureGold.rati)} রতি</span>
        `;
  }

  function convertToBanglaNumbers(number) {
    const banglaNumbers = {
      '0': '০',
      '1': '১',
      '2': '২',
      '3': '৩',
      '4': '৪',
      '5': '৫',
      '6': '৬',
      '7': '৭',
      '8': '৮',
      '9': '৯'
    };
    return number.toString().replace(/[0-9]/g, function(match) {
      return banglaNumbers[match];
    });
  }

  // Initialize the results on page load
  updateResults();
});