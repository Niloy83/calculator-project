document.addEventListener('DOMContentLoaded', function() {
  function initializeWeightOptions(selectElement, max, unit) {
    for (let i = 0; i <= max; i++) {
      const option = document.createElement("option");
      option.value = i;
      option.textContent = `${convertToBanglaNumbers(i)} ${unit}`;
      selectElement.appendChild(option);
    }
  }

  const newBhoriSelect = document.getElementById("new-bhori");
  const newAnaSelect = document.getElementById("new-ana");
  const newRatiSelect = document.getElementById("new-rati");
  const newPointSelect = document.getElementById("new-point");

  initializeWeightOptions(newBhoriSelect, 30, 'ভরি');
  initializeWeightOptions(newAnaSelect, 15, 'আনা');
  initializeWeightOptions(newRatiSelect, 5, 'রতি');
  initializeWeightOptions(newPointSelect, 9, 'পয়েন্ট');

  const oldBhoriSelect = document.getElementById("old-bhori");
  const oldAnaSelect = document.getElementById("old-ana");
  const oldRatiSelect = document.getElementById("old-rati");
  const oldPointSelect = document.getElementById("old-point");

  initializeWeightOptions(oldBhoriSelect, 30, 'ভরি');
  initializeWeightOptions(oldAnaSelect, 15, 'আনা');
  initializeWeightOptions(oldRatiSelect, 5, 'রতি');
  initializeWeightOptions(oldPointSelect, 9, 'পয়েন্ট');

  document.querySelectorAll('input[name="metal"]').forEach((element) => {
    element.addEventListener('change', handleMetalSelectionChange);
  });

  document.getElementById("live-price").addEventListener("change", handleLivePriceChange);

  document.getElementById("carat").addEventListener("change", handleCaratChange);

  document.getElementById("old-metal-checkbox").addEventListener("change", handleOldMetalCheckboxChange);

  document.getElementById("manual-wage").addEventListener("change", handleManualWageChange);

  const inputs = document.querySelectorAll('#manual-price, #wage-per-bhori, #new-bhori, #new-ana, #new-rati, #new-point, #old-bhori, #old-ana, #old-rati, #old-point');
  inputs.forEach(input => {
    input.addEventListener('input', calculateTotal);
  });

  // Fetch live prices initially
  fetchLivePrices();
});