// Fetch live prices from API and update the respective elements
function fetchLivePrices(callback) {
  const livePrices = {
    gold22k: 60000,
    gold21k: 57000,
    gold18k: 49000,
    silver: 800
  };

  document.getElementById("gold-22k-price").textContent = `${convertToBanglaNumbers(livePrices.gold22k)} টাকা`;
  document.getElementById("gold-21k-price").textContent = `${convertToBanglaNumbers(livePrices.gold21k)} টাকা`;
  document.getElementById("gold-18k-price").textContent = `${convertToBanglaNumbers(livePrices.gold18k)} টাকা`;
  document.getElementById("silver-price").textContent = `${convertToBanglaNumbers(livePrices.silver)} টাকা`;

  callback(livePrices);
}

// Update manual price input based on live prices and selected carat
function updateManualPriceInput(livePrices, carat, isGold) {
  const manualPriceInput = document.getElementById("manual-price");
  if (isGold) {
    switch (carat) {
      case '22':
        manualPriceInput.value = livePrices.gold22k;
        break;
      case '21':
        manualPriceInput.value = livePrices.gold21k;
        break;
      case '18':
        manualPriceInput.value = livePrices.gold18k;
        break;
    }
  } else {
    manualPriceInput.value = livePrices.silver;
  }
}

// Get live price value based on metal type and carat
function getLivePriceValue(isGold, carat) {
  if (isGold) {
    switch (carat) {
      case '22':
        return 60000;
      case '21':
        return 57000;
      case '18':
        return 49000;
    }
  } else {
    return 800;
  }
}