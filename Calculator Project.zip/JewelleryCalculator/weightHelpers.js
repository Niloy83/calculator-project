// Convert total weight from points to bhori, ana, rati, and point
function convertWeightFromPointsToUnits(totalWeightInPoints) {
  const totalWeightBhori = Math.floor(totalWeightInPoints / (16 * 6 * 10));
  const remainingPointsAfterBhori = totalWeightInPoints % (16 * 6 * 10);

  const totalWeightAna = Math.floor(remainingPointsAfterBhori / (6 * 10));
  const remainingPointsAfterAna = remainingPointsAfterBhori % (6 * 10);

  const totalWeightRati = Math.floor(remainingPointsAfterAna / 10);
  const totalWeightPoint = remainingPointsAfterAna % 10;

  return {
    bhori: totalWeightBhori,
    ana: totalWeightAna,
    rati: totalWeightRati,
    point: totalWeightPoint
  };
}

// Convert numbers to Bangla
function convertToBanglaNumbers(number) {
  const banglaNumbers = {
    '0': '০',
    '1': '১',
    '2': '২',
    '3': '৩',
    '4': '৪',
    '5': '৫',
    '6': '৬',
    '7': '৭',
    '8': '৮',
    '9': '৯'
  };
  return number.toString().replace(/[0-9]/g, function(match) {
    return banglaNumbers[match];
  });
}