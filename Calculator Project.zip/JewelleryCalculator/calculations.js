function calculateTotal() {
  const isGold = document.getElementById("gold").checked;
  const livePrice = document.getElementById("live-price").checked;
  const manualPrice = parseFloat(document.getElementById("manual-price").value);
  const carat = document.getElementById("carat").value;
  const manualWage = document.getElementById("manual-wage").checked;
  const wagePerBhori = parseFloat(document.getElementById("wage-per-bhori").value);

  const newBhori = parseFloat(document.getElementById("new-bhori").value) || 0;
  const newAna = parseFloat(document.getElementById("new-ana").value) || 0;
  const newRati = parseFloat(document.getElementById("new-rati").value) || 0;
  const newPoint = parseFloat(document.getElementById("new-point").value) || 0;

  const oldBhori = parseFloat(document.getElementById("old-bhori").value) || 0;
  const oldAna = parseFloat(document.getElementById("old-ana").value) || 0;
  const oldRati = parseFloat(document.getElementById("old-rati").value) || 0;
  const oldPoint = parseFloat(document.getElementById("old-point").value) || 0;

  // Calculate the total weight in bhori, ana, rati, and point
  const newTotalWeight = newBhori * 16 * 6 * 10 + newAna * 6 * 10 + newRati * 10 + newPoint;
  const oldTotalWeight = oldBhori * 16 * 6 * 10 + oldAna * 6 * 10 + oldRati * 10 + oldPoint;
  const totalWeightInPoints = newTotalWeight - oldTotalWeight;

  // Convert total weight from points to bhori, ana, rati, and point
  const totalWeightBhori = Math.floor(totalWeightInPoints / (16 * 6 * 10));
  const remainingPointsAfterBhori = totalWeightInPoints % (16 * 6 * 10);

  const totalWeightAna = Math.floor(remainingPointsAfterBhori / (6 * 10));
  const remainingPointsAfterAna = remainingPointsAfterBhori % (6 * 10);

  const totalWeightRati = Math.floor(remainingPointsAfterAna / 10);
  const totalWeightPoint = remainingPointsAfterAna % 10;

  let pricePerUnit = manualPrice;
  if (livePrice) {
    pricePerUnit = getLivePriceValue(isGold, carat);
  }

  const totalWeightInBhori = totalWeightInPoints / (16 * 6 * 10);
  const totalPrice = pricePerUnit * totalWeightInBhori;

  let totalWage = 0;
  if (manualWage) {
    totalWage = wagePerBhori;
  } else if (!isNaN(wagePerBhori)) {
    totalWage = wagePerBhori * totalWeightInBhori;
  }

  const finalPrice = totalPrice + totalWage;
  const selectedMetal = isGold ? "স্বর্ণ" : "রুপা";

  document.getElementById("result").innerHTML = `
        <p>ধাতু: ${selectedMetal}</p>
        <p>গহনার ওজন: ${convertToBanglaNumbers(newBhori)} ভরি ${convertToBanglaNumbers(newAna)} আনা ${convertToBanglaNumbers(newRati)} রতি ${convertToBanglaNumbers(newPoint)} পয়েন্ট</p>
        ${oldTotalWeight > 0 ? `<p>পুরান ${selectedMetal} এর ওজন: ${convertToBanglaNumbers(oldBhori)} ভরি ${convertToBanglaNumbers(oldAna)} আনা ${convertToBanglaNumbers(oldRati)} রতি ${convertToBanglaNumbers(oldPoint)} পয়েন্ট</p>` : ""}
        <p>নতুন ${selectedMetal}: ${convertToBanglaNumbers(totalWeightBhori)} ভরি ${convertToBanglaNumbers(totalWeightAna)} আনা ${convertToBanglaNumbers(totalWeightRati)} রতি ${convertToBanglaNumbers(totalWeightPoint)} পয়েন্ট</p>
        <p>${selectedMetal} মূল্য: ${convertToBanglaNumbers(totalPrice.toFixed(2))} টাকা</p>
        <div id="line"></div>
        ${!isNaN(wagePerBhori) ? `<p>মজুরি: ${convertToBanglaNumbers(totalWage.toFixed(2))} টাকা</p><div id="line"></div>` : ""}
        <p id="final-price">সর্ব মোট দাম: ${convertToBanglaNumbers(finalPrice.toFixed(2))} টাকা</p>
    `;
}