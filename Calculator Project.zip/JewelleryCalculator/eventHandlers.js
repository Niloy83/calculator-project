function handleMetalSelectionChange() {
  const selectedMetal = document.querySelector('input[name="metal"]:checked').value === 'gold' ? 'স্বর্ণ' : 'রুপা';
  const newMetalElement = document.getElementById("new-metal");
  const oldMetalElement = document.getElementById("old-metal");
  const oldMetalWeightElement = document.getElementById("old-metal-weight");

  if (newMetalElement) newMetalElement.textContent = selectedMetal;
  if (oldMetalElement) oldMetalElement.textContent = selectedMetal;
  if (oldMetalWeightElement) oldMetalWeightElement.textContent = selectedMetal;

  const isGold = selectedMetal === 'স্বর্ণ';
  const livePrice = document.getElementById("live-price").checked;
  const caratSelection = document.getElementById("carat-selection");

  if (isGold) {
    if (livePrice) {
      fetchLivePrices(function(livePrices) {
        const carat = document.getElementById("carat").value;
        updateManualPriceInput(livePrices, carat, isGold);
      });
    }
    caratSelection.style.display = 'block';
  } else {
    if (livePrice) {
      fetchLivePrices(function(livePrices) {
        document.getElementById("manual-price").value = livePrices.silver;
      });
    }
    caratSelection.style.display = 'none';
  }
  calculateTotal(); // Recalculate total whenever the metal selection changes
}

function handleLivePriceChange() {
  const manualPriceInput = document.getElementById("manual-price");
  const caratSelection = document.getElementById("carat-selection");
  const isGold = document.getElementById("gold").checked;
  if (this.checked) {
    manualPriceInput.disabled = true;
    fetchLivePrices(function(livePrices) {
      if (isGold) {
        const carat = document.getElementById("carat").value;
        updateManualPriceInput(livePrices, carat, isGold);
        caratSelection.style.display = 'block';
      } else {
        manualPriceInput.value = livePrices.silver;
        caratSelection.style.display = 'none';
      }
    });
  } else {
    manualPriceInput.disabled = false;
    caratSelection.style.display = 'none'; // Hide the carat selection if live price is not checked
    manualPriceInput.value = "";
  }
  calculateTotal(); // Recalculate total whenever the live price checkbox status changes
}

function handleCaratChange() {
  const livePriceCheckbox = document.getElementById("live-price");
  const isGold = document.getElementById("gold").checked;
  if (livePriceCheckbox.checked && isGold) {
    fetchLivePrices(function(livePrices) {
      const carat = document.getElementById("carat").value;
      updateManualPriceInput(livePrices, carat, isGold);
    });
  }
  calculateTotal(); // Recalculate total whenever the carat selection changes
}

function handleOldMetalCheckboxChange() {
  const oldWeightInput = document.getElementById("old-weight-input");
  if (this.checked) {
    oldWeightInput.style.display = 'block';
  } else {
    oldWeightInput.style.display = 'none';
  }
  calculateTotal(); // Recalculate total whenever the old metal checkbox status changes
}

function handleManualWageChange() {
  const wageInput = document.getElementById("wage-per-bhori");
  if (this.checked) {
    if (wageInput.value === "") {
      wageInput.placeholder = "মোট মজুরি";
    }
  } else {
    if (wageInput.value === "") {
      wageInput.placeholder = "ভরি প্রতি মজুরি";
    }
  }
  calculateTotal(); // Recalculate total whenever the manual wage checkbox status changes
}