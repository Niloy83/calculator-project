document.addEventListener('DOMContentLoaded', function() {
  const modeSwitch = document.getElementById('mode-switch');
  const mortgageSection = document.getElementById('mortgage-section');
  const redeemSection = document.getElementById('redeem-section');
  const labelMortgage = document.getElementById('label-mortgage');
  const labelRedeem = document.getElementById('label-redeem');

  const mortgageRateInput = document.getElementById('mortgage-rate');
  const voriInput = document.getElementById('vori');
  const anaInput = document.getElementById('ana');
  const ratiInput = document.getElementById('rati');
  const pointInput = document.getElementById('point');
  const resultMortgage = document.getElementById('result-mortgage');

  const principalAmountInput = document.getElementById('principal-amount');
  const interestRateInput = document.getElementById('interest-rate');
  const startDateInput = document.getElementById('start-date');
  const endDateInput = document.getElementById('end-date');
  const resultRedeem = document.getElementById('result-redeem');

  modeSwitch.addEventListener('change', function() {
    if (modeSwitch.checked) {
      mortgageSection.style.display = 'none';
      redeemSection.style.display = 'block';
      labelMortgage.classList.remove('active');
      labelRedeem.classList.add('active');
    } else {
      mortgageSection.style.display = 'block';
      redeemSection.style.display = 'none';
      labelMortgage.classList.add('active');
      labelRedeem.classList.remove('active');
    }
  });

  voriInput.addEventListener('input', calculateMortgage);
  anaInput.addEventListener('input', calculateMortgage);
  ratiInput.addEventListener('input', calculateMortgage);
  pointInput.addEventListener('input', calculateMortgage);
  mortgageRateInput.addEventListener('input', calculateMortgage);

  principalAmountInput.addEventListener('input', calculateInterest);
  interestRateInput.addEventListener('input', calculateInterest);
  startDateInput.addEventListener('input', calculateRedeem);
  endDateInput.addEventListener('input', calculateRedeem);

  function calculateMortgage() {
    const vori = parseFloat(voriInput.value) || 0;
    const ana = parseFloat(anaInput.value) || 0;
    const rati = parseFloat(ratiInput.value) || 0;
    const point = parseFloat(pointInput.value) || 0;
    const mortgageRate = parseFloat(mortgageRateInput.value) || 0;

    if (ana < 0 || ana > 15) {
      anaInput.style.borderColor = 'red';
      resultMortgage.innerHTML = 'আনা ০ থেকে ১৫ এর মধ্যে হতে হবে';
      return;
    } else {
      anaInput.style.borderColor = '#ced4da';
    }

    if (rati < 0 || rati > 5) {
      ratiInput.style.borderColor = 'red';
      resultMortgage.innerHTML = 'রতি ০ থেকে ৫ এর মধ্যে হতে হবে';
      return;
    } else {
      ratiInput.style.borderColor = '#ced4da';
    }

    if (point < 0 || point > 9) {
      pointInput.style.borderColor = 'red';
      resultMortgage.innerHTML = 'পয়েন্ট ০ থেকে ৯ এর মধ্যে হতে হবে';
      return;
    } else {
      pointInput.style.borderColor = '#ced4da';
    }

    const totalWeightInVori = vori + (ana / 16) + (rati / 96) + (point / 960);
    const totalAmount = totalWeightInVori * mortgageRate;

    resultMortgage.innerHTML = `
            <span class="bold">মোট টাকা: ${convertToBanglaNumbers(Math.round(totalAmount))} টাকা</span>
        `;
  }

  function calculateInterest() {
    const principal = parseFloat(principalAmountInput.value) || 0;
    const interestRate = parseFloat(interestRateInput.value) || 0;
    const monthlyInterest = principal * (interestRate / 100);

    resultRedeem.innerHTML = `
            <span>প্রতি মাসে মুনাফা: ${convertToBanglaNumbers(Math.round(monthlyInterest))} টাকা</span>
        `;

    calculateRedeem();
  }

  function calculateRedeem() {
    const principal = parseFloat(principalAmountInput.value) || 0;
    const interestRate = parseFloat(interestRateInput.value) || 0;
    const startDate = new Date(startDateInput.value);
    const endDate = new Date(endDateInput.value);

    if (startDate > endDate) {
      resultRedeem.innerHTML = 'প্রবেশকৃত তারিখ সঠিক নয়';
      return;
    }

    let daysDiff = Math.ceil((endDate - startDate) / (1000 * 3600 * 24));

    // Calculate the number of 31st, 29th, and 28th days in the period
    let numberOf31stDays = 0;
    let numberOf29thDays = 0;
    let numberOf28thDays = 0;

    for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
      if (d.getDate() === 31) {
        numberOf31stDays++;
      } else if (d.getDate() === 29 && d.getMonth() === 1) {
        numberOf29thDays++;
      } else if (d.getDate() === 28 && d.getMonth() === 1 && !isLeapYear(d.getFullYear())) {
        numberOf28thDays++;
      }
    }

    // Adjust the total days with the number of 31st, 29th, and 28th days
    daysDiff -= numberOf31stDays;
    daysDiff += numberOf29thDays;
    daysDiff += 2 * numberOf28thDays;

    // Calculate the number of months and remaining days after adjustment
    let totalMonths = Math.floor(daysDiff / 30);
    const remainingDays = daysDiff % 30;

    // Calculate the number of years, months, and days
    const years = Math.floor(totalMonths / 12);
    const months = totalMonths % 12;
    const days = remainingDays;

    // Calculate total months including partial months
    if (days >= 18) {
      totalMonths += 1;
    } else if (days >= 4) {
      totalMonths += 0.5;
    }

    // If the duration is less than 1 month, consider it as 1 month
    if (totalMonths < 1) {
      totalMonths = 1;
    }

    const monthlyInterest = principal * (interestRate / 100);
    const totalInterest = monthlyInterest * totalMonths;
    const totalAmount = principal + totalInterest;

    // Construct the duration display string
    let durationDisplay = "";
    if (years > 0) {
      durationDisplay += `${convertToBanglaNumbers(years)} বছর`;
    }
    if (months > 0) {
      durationDisplay += ` ${convertToBanglaNumbers(months)} মাস`;
    }
    if (days > 0) {
      durationDisplay += ` ${convertToBanglaNumbers(days)} দিন`;
    }

    resultRedeem.innerHTML = `
            <span>মেয়াদকাল: ${durationDisplay.trim()}</span><br>
            <span>প্রতি মাসে মুনাফা: ${convertToBanglaNumbers(Math.round(monthlyInterest))} টাকা</span><br>
            <span class="bold">আসল টাকা: ${convertToBanglaNumbers(Math.round(principal))} টাকা</span><br>
            <span class="highlight">মোট মুনাফা: ${convertToBanglaNumbers(Math.round(totalInterest))} টাকা (${convertToBanglaNumbers(totalMonths)} মাস)</span><br>
            <span class="highlight">সর্বমোট: ${convertToBanglaNumbers(Math.round(totalAmount))} টাকা</span>
        `;
  }

  function isLeapYear(year) {
    return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
  }

  function convertToBanglaNumbers(number) {
    const banglaNumbers = {
      '0': '০',
      '1': '১',
      '2': '২',
      '3': '৩',
      '4': '৪',
      '5': '৫',
      '6': '৬',
      '7': '৭',
      '8': '৮',
      '9': '৯'
    };
    return number.toString().replace(/[0-9]/g, function(match) {
      return banglaNumbers[match];
    });
  }
});